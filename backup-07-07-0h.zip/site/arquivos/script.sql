create table tbl_usuario(
    codigo integer not null AUTO_INCREMENT primary key,
    nomer varchar(150),
    email varchar(150));