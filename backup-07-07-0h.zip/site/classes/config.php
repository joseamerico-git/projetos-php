<?php 

namespace classes;

 define ('HOST', "localhost");
 define ('USER', "root");
 define ('PASS', "");
 define ('BASE', "banco-siuspf");
 
 //header("Content-type: text/html; charset=utf-8"); 




?>