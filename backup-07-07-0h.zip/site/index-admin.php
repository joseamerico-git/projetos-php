<html>
 <?php


 header("Content-type: text/html; charset=utf-8");
 
 ?>
   
   <head>
   	<title>Admin-<?php ?></title>
   	<meta charset="utf-8">
   
   	<lang = "pt-br">
   
   </head>
   
   
   <body>
   
   <?php require_once 'componentes/menu-admin.php';?>
   
   <a class="btn btn-outline-success my-2 my-sm-0" href="\site\\index.php">Ver a p�gina Inicial</a><br>
   <a class="btn btn-outline-success my-2 my-sm-0" href="\site\\cadastro_usuario.php">Cadastrar Usu�rios</a><br>
   <a class="btn btn-outline-success my-2 my-sm-0" href="\site\\cadastro_evento.php">Cadastrar Eventos</a><br>
   

</div>
  	 
   
   
   </body>

       

</html>